/*
Homework #1
Homework01_Group7
Kevin Heu, Samuel Petty
 */

package com.example.kevin.hw1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class Create extends AppCompatActivity {

    private static final int ICAP = 113;

    byte[] byteArray;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.default_image);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byteArray = stream.toByteArray();

        findViewById(R.id.saveBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fname, lname, company = "", phone, email = "", url = "", address = "", birthday = "", nickname = "", fbURL = "", twitterURL = "", skypeURL = "", youtubeChannel = "";
                boolean fCheck = true, lCheck = true, pCheck = true;

                if (((EditText) findViewById(R.id.fName)).getText().toString().isEmpty()) {
                    fCheck = false;
                    Toast.makeText(Create.this, "Please enter your first name", Toast.LENGTH_SHORT).show();
                }

                if (((EditText) findViewById(R.id.lName)).getText().toString().isEmpty()) {
                    lCheck = false;
                    Toast.makeText(Create.this, "Please enter your last name", Toast.LENGTH_SHORT).show();
                }

                if (((EditText) findViewById(R.id.pNum)).getText().toString().isEmpty()) {
                    pCheck = false;
                    Toast.makeText(Create.this, "Please enter your Phone", Toast.LENGTH_SHORT).show();
                }

                if (lCheck && fCheck && pCheck) {
                    fname = ((EditText) findViewById(R.id.fName)).getText().toString();
                    lname = ((EditText) findViewById(R.id.lName)).getText().toString();
                    phone = ((EditText) findViewById(R.id.pNum)).getText().toString();

                    if (((EditText) findViewById(R.id.cName)).getText().toString() != null)
                        company = ((EditText) findViewById(R.id.cName)).getText().toString();

                    if (((EditText) findViewById(R.id.email)).getText().toString() != null)
                        email = ((EditText) findViewById(R.id.email)).getText().toString();

                    if (((EditText) findViewById(R.id.url)).getText().toString() != null)
                        url = ((EditText) findViewById(R.id.url)).getText().toString();

                    if (((EditText) findViewById(R.id.address)).getText().toString() != null)
                        address = ((EditText) findViewById(R.id.address)).getText().toString();

                    if (((EditText) findViewById(R.id.bDay)).getText().toString() != null)
                        birthday = ((EditText) findViewById(R.id.bDay)).getText().toString();

                    if (((EditText) findViewById(R.id.nName)).getText().toString() != null)
                        nickname = ((EditText) findViewById(R.id.nName)).getText().toString();

                    if (((EditText) findViewById(R.id.fbURL)).getText().toString() != null)
                        fbURL = ((EditText) findViewById(R.id.fbURL)).getText().toString();

                    if (((EditText) findViewById(R.id.twURL)).getText().toString() != null)
                        twitterURL = ((EditText) findViewById(R.id.twURL)).getText().toString();

                    if (((EditText) findViewById(R.id.skype)).getText().toString() != null)
                        skypeURL = ((EditText) findViewById(R.id.skype)).getText().toString();

                    if (((EditText) findViewById(R.id.ytURL)).getText().toString() != null)
                        youtubeChannel = ((EditText) findViewById(R.id.ytURL)).getText().toString();

                    User newContact = new User(byteArray, fname, lname, company, phone, email, url, address, birthday, nickname, fbURL, twitterURL, skypeURL, youtubeChannel);
                    Intent intent = new Intent();
                    intent.putExtra("NEW_CONTACT", newContact);
                    setResult(RESULT_OK, intent);

                    finish();

                }
            }
        });

    }

    public void onCamera(View view) {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(cameraIntent, ICAP);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == ICAP) {
            Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
            ImageView img = findViewById(R.id.profile);
            img.setImageBitmap(imageBitmap);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byteArray = stream.toByteArray();
        }

    }

}

