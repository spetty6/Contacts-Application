/*
Homework #1
Homework01_Group7
Kevin Heu, Samuel Petty
 */

package com.example.kevin.hw1;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class DisplayView extends AppCompatActivity implements View.OnClickListener{

    static final String CONTACT = "CONTACT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_view);

        if(getIntent() != null && getIntent().getExtras() != null){


            User thisuser = (User) getIntent().getExtras().get(CONTACT);

            byte[] byteArray =  thisuser.getPhoto();
            ((ImageView) findViewById(R.id.viewprofilephoto)).setImageBitmap(BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length));
            ((TextView) findViewById(R.id.viewfirstname)).setText( thisuser.getFname());
            ((TextView) findViewById(R.id.viewlastname)).setText( thisuser.getLname());
            ((TextView) findViewById(R.id.viewaddress)).setText( thisuser.getAddress());
            ((TextView) findViewById(R.id.viewbirthday)).setText( thisuser.getBday());
            ((TextView) findViewById(R.id.viewcompany)).setText( thisuser.getCmpany());
            ((TextView) findViewById(R.id.viewemail)).setText( thisuser.getEmail());
            ((TextView) findViewById(R.id.viewfburl)).setText( thisuser.getFbURL());
            ((TextView) findViewById(R.id.viewnickname)).setText( thisuser.getNname());
            ((TextView) findViewById(R.id.viewphone)).setText( thisuser.getPhone());
            ((TextView) findViewById(R.id.viewskype)).setText( thisuser.getSkURL());
            ((TextView) findViewById(R.id.viewtwitterurl)).setText( thisuser.getTwURL());
            ((TextView) findViewById(R.id.viewurl)).setText( thisuser.getUrl());
            ((TextView) findViewById(R.id.viewyoutube)).setText( thisuser.getYtURL());

        }

        if(!((TextView)findViewById(R.id.viewurl)).getText().toString().trim().isEmpty())
            findViewById(R.id.viewurl).setOnClickListener(this);
        if(!((TextView)findViewById(R.id.viewfburl)).getText().toString().trim().isEmpty())
            findViewById(R.id.viewfburl).setOnClickListener(this);
        if(!((TextView)findViewById(R.id.viewskype)).getText().toString().trim().isEmpty())
            findViewById(R.id.viewskype).setOnClickListener(this);
        if(!((TextView)findViewById(R.id.viewtwitterurl)).getText().toString().trim().isEmpty())
            findViewById(R.id.viewtwitterurl).setOnClickListener(this);
        if(!((TextView)findViewById(R.id.viewyoutube)).getText().toString().trim().isEmpty())
            findViewById(R.id.viewyoutube).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        Intent i = new Intent();
    }
}
