/*
Homework #1
Homework01_Group7
Kevin Heu, Samuel Petty
 */

package com.example.kevin.hw1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static ArrayList<User> contact = new ArrayList<>();
    static final int CCODE = 100;
    static final int DCODE = 111;
    static final int ECODE = 112;
    static final String CKEY = "NEW_CONTACT";
    static final String UPDATE = "UPDATE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == CCODE){
            if(resultCode == RESULT_OK){
                User person = (User) data.getExtras().get(CKEY);
                contact.add(person);
            }
        }
        if(requestCode == ECODE || requestCode == DCODE){
            if(resultCode == RESULT_OK){
                contact = (ArrayList<User>) data.getExtras().get(UPDATE);
            }
        }


    }
    public void onCreateClick(View view){
        Intent intent = new Intent(MainActivity.this, Create.class);
        startActivityForResult(intent, CCODE);
    }
    public void onEdit(View view){
        Intent intent = new Intent(MainActivity.this, Display.class);
        if(contact.size() > 0) {
            intent.putExtra("CONTACTS", contact);
            intent.putExtra("VIEW", false);
            intent.putExtra("EDIT", true);
            intent.putExtra("DELETE", false);
            startActivityForResult(intent, ECODE);
        }else
            Toast.makeText(this, "There are no contacts to edit", Toast.LENGTH_SHORT).show();
        Log.d("test", "Finished editing contact");
    }
    public void onDelete(View view){
        Intent intent = new Intent(MainActivity.this, Display.class);
        if(contact.size() > 0) {
            intent.putExtra("CONTACTS", contact);
            intent.putExtra("VIEW", false);
            intent.putExtra("EDIT", false);
            intent.putExtra("DELETE", true);
            startActivityForResult(intent, DCODE);
        }else
            Toast.makeText(this, "There are no contacts to Delete", Toast.LENGTH_SHORT).show();
    }
    public void onDisplay(View view){
        Intent intent = new Intent(MainActivity.this, Display.class);
        if(contact.size() > 0) {
            intent.putExtra("CONTACTS", contact);
            intent.putExtra("VIEW", true);
            intent.putExtra("EDIT", false);
            intent.putExtra("DELETE", false);
            startActivity(intent);
        }else
            Toast.makeText(this, "There are no contacts to show", Toast.LENGTH_SHORT).show();
    }
    public void onFinish(View view){
    finish();
    }
}
