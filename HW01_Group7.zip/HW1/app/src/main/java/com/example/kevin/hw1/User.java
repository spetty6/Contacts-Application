/*
Homework #1
Homework01_Group7
Kevin Heu, Samuel Petty
 */

package com.example.kevin.hw1;

import java.io.Serializable;


public class User implements Serializable {
    private String fname, lname, cmpany, phone, email, url, address, bday, nname, fbURL, twURL, skURL, ytURL;
    private byte[] photo;

    public User(byte[] pto,String fname, String lname, String cmpany, String phone, String email, String url, String address, String bday, String nname, String fbURL, String twURL, String skURL, String ytURL) {
        this.fname = fname;
        this.lname = lname;
        this.cmpany = cmpany;
        this.phone = phone;
        this.email = email;
        this.url = url;
        this.address = address;
        this.bday = bday;
        this.nname = nname;
        this.fbURL = fbURL;
        this.twURL = twURL;
        this.skURL = skURL;
        this.ytURL = ytURL;
        this.photo = pto;
    }

    public String getFname() {
        return fname;
    }
    public String getLname() {
        return lname;
    }
    public String getCmpany() {
        return cmpany;
    }
    public String getPhone() {
        return phone;
    }
    public String getEmail() {
        return email;
    }
    public String getUrl() {
        return url;
    }
    public String getAddress() {
        return address;
    }
    public String getBday() {
        return bday;
    }
    public String getNname() {
        return nname;
    }
    public String getFbURL() {
        return fbURL;
    }
    public String getTwURL() {
        return twURL;
    }
    public String getSkURL() {
        return skURL;
    }
    public String getYtURL() {
        return ytURL;
    }
    public byte[] getPhoto() {
        return photo;
    }

}
